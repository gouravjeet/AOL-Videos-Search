Project Structure:

All files should reside in the same folder.

1) Images are in the images folder
2) main.html is the main HTML file
3) main.css is the main css file
4) script.js is the main javascript file